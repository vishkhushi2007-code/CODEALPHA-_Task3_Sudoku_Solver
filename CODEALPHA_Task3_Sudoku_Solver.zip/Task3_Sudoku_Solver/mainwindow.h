#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>
#include <QMessageBox>
#include <QIntValidator>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void solveButtonClicked();
    void clearButtonClicked();
    void loadExample();

private:
    QLineEdit *cells[9][9];
    QPushButton *solveBtn;
    QPushButton *clearBtn;
    QPushButton *exampleBtn;

    bool isSafe(int grid[9][9], int row, int col, int num);
    bool findEmpty(int grid[9][9], int &row, int &col);
    bool solveSudoku(int grid[9][9]);
    void getGridFromUI(int grid[9][9]);
    void setGridToUI(int grid[9][9]);
};

#endif // MAINWINDOW_H
