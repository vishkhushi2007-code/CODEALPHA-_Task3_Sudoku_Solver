#include <iostream>
#include <vector>
using namespace std;

const int N = 9;

// Print the Sudoku grid
void printGrid(int grid[N][N]) {
    cout << "\n+-------+-------+-------+\n";
    for (int row = 0; row < N; row++) {
        cout << "| ";
        for (int col = 0; col < N; col++) {
            if (grid[row][col] == 0)
                cout << ". ";
            else
                cout << grid[row][col] << " ";
            if ((col + 1) % 3 == 0)
                cout << "| ";
        }
        cout << endl;
        if ((row + 1) % 3 == 0)
            cout << "+-------+-------+-------+\n";
    }
}

// Check if placing num at (row, col) is valid
bool isSafe(int grid[N][N], int row, int col, int num) {
    // Check row
    for (int x = 0; x < N; x++)
        if (grid[row][x] == num)
            return false;

    // Check column
    for (int x = 0; x < N; x++)
        if (grid[x][col] == num)
            return false;

    // Check 3x3 subgrid
    int startRow = row - row % 3;
    int startCol = col - col % 3;

    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (grid[i + startRow][j + startCol] == num)
                return false;

    return true;
}

// Find the next empty cell
bool findEmptyCell(int grid[N][N], int &row, int &col) {
    for (row = 0; row < N; row++)
        for (col = 0; col < N; col++)
            if (grid[row][col] == 0)
                return true;
    return false;
}

// Backtracking Solver
bool solveSudoku(int grid[N][N]) {
    int row, col;

    if (!findEmptyCell(grid, row, col))
        return true;

    for (int num = 1; num <= 9; num++) {
        if (isSafe(grid, row, col, num)) {
            grid[row][col] = num;

            if (solveSudoku(grid))
                return true;

            grid[row][col] = 0; // backtrack
        }
    }
    return false;
}

int main() {
    // Example Sudoku puzzle (0 = empty)
    int grid[N][N] = {
        {5, 3, 0, 0, 7, 0, 0, 0, 0},
        {6, 0, 0, 1, 9, 5, 0, 0, 0},
        {0, 9, 8, 0, 0, 0, 0, 6, 0},
        {8, 0, 0, 0, 6, 0, 0, 0, 3},
        {4, 0, 0, 8, 0, 3, 0, 0, 1},
        {7, 0, 0, 0, 2, 0, 0, 0, 6},
        {0, 6, 0, 0, 0, 0, 2, 8, 0},
        {0, 0, 0, 4, 1, 9, 0, 0, 5},
        {0, 0, 0, 0, 8, 0, 0, 7, 9}
    };

    cout << "========== SUDOKU SOLVER (Console) ==========\n";
    cout << "\nOriginal Puzzle:";
    printGrid(grid);

    if (solveSudoku(grid)) {
        cout << "\nSolved Sudoku:";
        printGrid(grid);
        cout << "\nSudoku solved successfully!\n";
    } else {
        cout << "\nNo solution exists for this puzzle.\n";
    }

    return 0;
}
