#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QFont>
#include <QIntValidator>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle("Sudoku Solver - Backtracking");
    setFixedSize(520, 620);

    QWidget *central = new QWidget(this);
    setCentralWidget(central);

    QVBoxLayout *mainLayout = new QVBoxLayout(central);

    // Title
    QLabel *title = new QLabel("SUDOKU SOLVER");
    title->setAlignment(Qt::AlignCenter);
    QFont titleFont = title->font();
    titleFont.setPointSize(18);
    titleFont.setBold(true);
    title->setFont(titleFont);
    mainLayout->addWidget(title);

    // Grid of 9x9 input boxes
    QGridLayout *gridLayout = new QGridLayout();
    gridLayout->setSpacing(2);

    QFont cellFont;
    cellFont.setPointSize(14);
    cellFont.setBold(true);

    for (int row = 0; row < 9; row++) {
        for (int col = 0; col < 9; col++) {
            cells[row][col] = new QLineEdit();
            cells[row][col]->setFixedSize(45, 45);
            cells[row][col]->setAlignment(Qt::AlignCenter);
            cells[row][col]->setFont(cellFont);
            cells[row][col]->setMaxLength(1);

            // Only allow numbers 1-9
            cells[row][col]->setValidator(new QIntValidator(1, 9, this));

            // Visual separation for 3x3 boxes
            QString style = "QLineEdit { border: 1px solid #555; background: white; }";
            if (row % 3 == 0) style += "QLineEdit { border-top: 2px solid black; }";
            if (col % 3 == 0) style += "QLineEdit { border-left: 2px solid black; }";
            if (row == 8) style += "QLineEdit { border-bottom: 2px solid black; }";
            if (col == 8) style += "QLineEdit { border-right: 2px solid black; }";

            cells[row][col]->setStyleSheet(style);
            gridLayout->addWidget(cells[row][col], row, col);
        }
    }

    mainLayout->addLayout(gridLayout);

    // Buttons
    QHBoxLayout *btnLayout = new QHBoxLayout();

    solveBtn = new QPushButton("Solve");
    clearBtn = new QPushButton("Clear");
    exampleBtn = new QPushButton("Load Example");

    solveBtn->setFixedHeight(40);
    clearBtn->setFixedHeight(40);
    exampleBtn->setFixedHeight(40);

    solveBtn->setStyleSheet("QPushButton { background-color: #4CAF50; color: white; font-weight: bold; }");
    clearBtn->setStyleSheet("QPushButton { background-color: #f44336; color: white; font-weight: bold; }");
    exampleBtn->setStyleSheet("QPushButton { background-color: #2196F3; color: white; font-weight: bold; }");

    btnLayout->addWidget(exampleBtn);
    btnLayout->addWidget(clearBtn);
    btnLayout->addWidget(solveBtn);

    mainLayout->addLayout(btnLayout);

    // Connect signals
    connect(solveBtn, &QPushButton::clicked, this, &MainWindow::solveButtonClicked);
    connect(clearBtn, &QPushButton::clicked, this, &MainWindow::clearButtonClicked);
    connect(exampleBtn, &QPushButton::clicked, this, &MainWindow::loadExample);
}

MainWindow::~MainWindow() {}

// ========== Sudoku Logic ==========

bool MainWindow::isSafe(int grid[9][9], int row, int col, int num) {
    for (int x = 0; x < 9; x++)
        if (grid[row][x] == num || grid[x][col] == num)
            return false;

    int startRow = row - row % 3;
    int startCol = col - col % 3;

    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (grid[i + startRow][j + startCol] == num)
                return false;

    return true;
}

bool MainWindow::findEmpty(int grid[9][9], int &row, int &col) {
    for (row = 0; row < 9; row++)
        for (col = 0; col < 9; col++)
            if (grid[row][col] == 0)
                return true;
    return false;
}

bool MainWindow::solveSudoku(int grid[9][9]) {
    int row, col;
    if (!findEmpty(grid, row, col))
        return true;

    for (int num = 1; num <= 9; num++) {
        if (isSafe(grid, row, col, num)) {
            grid[row][col] = num;
            if (solveSudoku(grid))
                return true;
            grid[row][col] = 0; // backtrack
        }
    }
    return false;
}

void MainWindow::getGridFromUI(int grid[9][9]) {
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
            QString text = cells[i][j]->text().trimmed();
            grid[i][j] = text.isEmpty() ? 0 : text.toInt();
        }
    }
}

void MainWindow::setGridToUI(int grid[9][9]) {
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
            if (grid[i][j] == 0)
                cells[i][j]->clear();
            else
                cells[i][j]->setText(QString::number(grid[i][j]));
        }
    }
}

// ========== Button Handlers ==========

void MainWindow::solveButtonClicked() {
    int grid[9][9];
    getGridFromUI(grid);

    if (solveSudoku(grid)) {
        setGridToUI(grid);
        QMessageBox::information(this, "Success", "Sudoku solved successfully!");
    } else {
        QMessageBox::warning(this, "No Solution", "This puzzle has no solution.");
    }
}

void MainWindow::clearButtonClicked() {
    for (int i = 0; i < 9; i++)
        for (int j = 0; j < 9; j++)
            cells[i][j]->clear();
}

void MainWindow::loadExample() {
    int example[9][9] = {
        {5,3,0,0,7,0,0,0,0},
        {6,0,0,1,9,5,0,0,0},
        {0,9,8,0,0,0,0,6,0},
        {8,0,0,0,6,0,0,0,3},
        {4,0,0,8,0,3,0,0,1},
        {7,0,0,0,2,0,0,0,6},
        {0,6,0,0,0,0,2,8,0},
        {0,0,0,4,1,9,0,0,5},
        {0,0,0,0,8,0,0,7,9}
    };
    setGridToUI(example);
}
